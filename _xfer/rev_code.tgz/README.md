# hgp

로그라이크 2D 액션 플랫포머 (Godot 4.x)

## 문서

- 기획: docs/GDD.md
- 런 구조: docs/RUN_STRUCTURE.md
- 로드맵: docs/ROADMAP.md
- 결정 기록: docs/DECISIONS.md
- 진행 로그: docs/PROGRESS.md
- 컨벤션: docs/CONVENTIONS.md
- 개발 하네스: docs/HARNESS.md
- Mac 환경 셋업: docs/MAC_SETUP.md
- M1 실행과 판정: docs/M1_CHECKLIST.md
- 프로토타입 범위: docs/PROTOTYPE.md
- 방 규격: docs/ROOM_SPEC.md
- 컨셉 브리프(외부용): docs/CONCEPT_BRIEF.md
- 디자인 트랙: docs/DESIGN_TRACK.md
- 막별 상세: docs/DESIGN_ACT1.md, docs/DESIGN_ACT2.md, docs/act1/
- 막 공통 시스템: docs/systems/ (RELICS 유물, BOONS 신내림 권능)
- 아트 파이프라인: docs/ART_PIPELINE.md, docs/ART_PIPELINE_SETUP.md
- 고증 자료: reference/ (act1_dokkaebi 도깨비, pantheon 신격과 무속 용어)
- 협업 지침: CLAUDE.md
x
